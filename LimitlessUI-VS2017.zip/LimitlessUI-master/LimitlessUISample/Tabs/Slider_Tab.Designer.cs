﻿using LimitlessUI;

namespace LimitlessUISample.Tabs
{
    partial class Slider_Tab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.slider_WOC1 = new Slider_WOC();
            this.slider_WOC2 = new Slider_WOC();
            this.slider_WOC3 = new Slider_WOC();
            this.slider_WOC4 = new Slider_WOC();
            this.slider_WOC5 = new Slider_WOC();
            this.slider_WOC6 = new Slider_WOC();
            this.SuspendLayout();
            // 
            // slider_WOC1
            // 
            this.slider_WOC1.BackLineThikness = 10F;
            this.slider_WOC1.CircleSize = 20F;
            this.slider_WOC1.Dock = System.Windows.Forms.DockStyle.Top;
            this.slider_WOC1.DrawCircle = true;
            this.slider_WOC1.ForeColor = System.Drawing.Color.SeaGreen;
            this.slider_WOC1.FrontLineThikness = 10F;
            this.slider_WOC1.Location = new System.Drawing.Point(0, 0);
            this.slider_WOC1.MaxValue = 100F;
            this.slider_WOC1.Name = "slider_WOC1";
            this.slider_WOC1.Rounded = false;
            this.slider_WOC1.Size = new System.Drawing.Size(803, 40);
            this.slider_WOC1.TabIndex = 0;
            this.slider_WOC1.Text = "slider_WOC1";
            this.slider_WOC1.Value = 6.385696F;
            // 
            // slider_WOC2
            // 
            this.slider_WOC2.BackLineThikness = 10F;
            this.slider_WOC2.CircleSize = 20F;
            this.slider_WOC2.Dock = System.Windows.Forms.DockStyle.Top;
            this.slider_WOC2.DrawCircle = true;
            this.slider_WOC2.ForeColor = System.Drawing.Color.SeaGreen;
            this.slider_WOC2.FrontLineThikness = 10F;
            this.slider_WOC2.Location = new System.Drawing.Point(0, 40);
            this.slider_WOC2.MaxValue = 100F;
            this.slider_WOC2.Name = "slider_WOC2";
            this.slider_WOC2.Rounded = true;
            this.slider_WOC2.Size = new System.Drawing.Size(803, 40);
            this.slider_WOC2.TabIndex = 1;
            this.slider_WOC2.Text = "slider_WOC2";
            this.slider_WOC2.Value = 6.385696F;
            // 
            // slider_WOC3
            // 
            this.slider_WOC3.BackLineThikness = 10F;
            this.slider_WOC3.CircleSize = 20F;
            this.slider_WOC3.Dock = System.Windows.Forms.DockStyle.Top;
            this.slider_WOC3.DrawCircle = false;
            this.slider_WOC3.ForeColor = System.Drawing.Color.SeaGreen;
            this.slider_WOC3.FrontLineThikness = 10F;
            this.slider_WOC3.Location = new System.Drawing.Point(0, 80);
            this.slider_WOC3.MaxValue = 100F;
            this.slider_WOC3.Name = "slider_WOC3";
            this.slider_WOC3.Rounded = true;
            this.slider_WOC3.Size = new System.Drawing.Size(803, 40);
            this.slider_WOC3.TabIndex = 2;
            this.slider_WOC3.Text = "slider_WOC3";
            this.slider_WOC3.Value = 6.385696F;
            // 
            // slider_WOC4
            // 
            this.slider_WOC4.BackLineThikness = 7F;
            this.slider_WOC4.CircleSize = 20F;
            this.slider_WOC4.Dock = System.Windows.Forms.DockStyle.Top;
            this.slider_WOC4.DrawCircle = false;
            this.slider_WOC4.ForeColor = System.Drawing.Color.SeaGreen;
            this.slider_WOC4.FrontLineThikness = 10F;
            this.slider_WOC4.Location = new System.Drawing.Point(0, 200);
            this.slider_WOC4.MaxValue = 100F;
            this.slider_WOC4.Name = "slider_WOC4";
            this.slider_WOC4.Rounded = true;
            this.slider_WOC4.Size = new System.Drawing.Size(803, 40);
            this.slider_WOC4.TabIndex = 5;
            this.slider_WOC4.Text = "slider_WOC4";
            this.slider_WOC4.Value = 6.385696F;
            // 
            // slider_WOC5
            // 
            this.slider_WOC5.BackLineThikness = 7F;
            this.slider_WOC5.CircleSize = 20F;
            this.slider_WOC5.Dock = System.Windows.Forms.DockStyle.Top;
            this.slider_WOC5.DrawCircle = true;
            this.slider_WOC5.ForeColor = System.Drawing.Color.SeaGreen;
            this.slider_WOC5.FrontLineThikness = 10F;
            this.slider_WOC5.Location = new System.Drawing.Point(0, 160);
            this.slider_WOC5.MaxValue = 100F;
            this.slider_WOC5.Name = "slider_WOC5";
            this.slider_WOC5.Rounded = true;
            this.slider_WOC5.Size = new System.Drawing.Size(803, 40);
            this.slider_WOC5.TabIndex = 4;
            this.slider_WOC5.Text = "slider_WOC5";
            this.slider_WOC5.Value = 6.385696F;
            // 
            // slider_WOC6
            // 
            this.slider_WOC6.BackLineThikness = 7F;
            this.slider_WOC6.CircleSize = 20F;
            this.slider_WOC6.Dock = System.Windows.Forms.DockStyle.Top;
            this.slider_WOC6.DrawCircle = true;
            this.slider_WOC6.ForeColor = System.Drawing.Color.SeaGreen;
            this.slider_WOC6.FrontLineThikness = 10F;
            this.slider_WOC6.Location = new System.Drawing.Point(0, 120);
            this.slider_WOC6.MaxValue = 100F;
            this.slider_WOC6.Name = "slider_WOC6";
            this.slider_WOC6.Rounded = false;
            this.slider_WOC6.Size = new System.Drawing.Size(803, 40);
            this.slider_WOC6.TabIndex = 3;
            this.slider_WOC6.Text = "slider_WOC6";
            this.slider_WOC6.Value = 6.385696F;
            // 
            // Slider_Tab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.slider_WOC4);
            this.Controls.Add(this.slider_WOC5);
            this.Controls.Add(this.slider_WOC6);
            this.Controls.Add(this.slider_WOC3);
            this.Controls.Add(this.slider_WOC2);
            this.Controls.Add(this.slider_WOC1);
            this.Name = "Slider_Tab";
            this.Size = new System.Drawing.Size(803, 507);
            this.ResumeLayout(false);

        }

        #endregion

        private Slider_WOC slider_WOC1;
        private Slider_WOC slider_WOC2;
        private Slider_WOC slider_WOC3;
        private Slider_WOC slider_WOC4;
        private Slider_WOC slider_WOC5;
        private Slider_WOC slider_WOC6;
    }
}
